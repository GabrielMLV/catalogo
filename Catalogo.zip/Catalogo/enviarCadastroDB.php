<head>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet">
</head>
<?php
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
include 'config.inc.php';

 if($_POST){
     $email = $_POST['email'];
     $emailConfirma  = $_POST['emailConfirma'];
     $dia = $_POST['dia'];
     $mes = $_POST['mes'];
     $ano = $_POST['ano']; 
     //Trecho de validação da Data de Nascimento digitada
     if($dia <= 0 || $dia >=32 || $mes <=0 || $mes >= 13 || $ano <= 1900 || $ano >= 2100){
        $_SESSION['data_errada'] = "<div class='alert alert-danger' role='alert'>Data de nascimento inválida!</div>";
        echo "<script>window.location.href='cadastro.php'</script>";
     }else{
        //Comparação de email digitado        
        if($email == $emailConfirma){ 
            //Validação se existe email no banco de dados
            $validaEmail = mysqli_query($conexao, "SELECT * FROM cadastro WHERE email = '$email' ");
            if(mysqli_num_rows($validaEmail) == 1){
                $_SESSION['email_cadastrado'] = "<div class='alert alert-danger alert-dismissible fade show' role='alert'>Email já cadastrado.</div>";
                echo "<script>window.location.href='cadastro.php'</script>";
            }else{ 
            $nome = $_POST['nome'];
            $lagradouro = $_POST['lagradouro'];
            $numero = $_POST['numero'];
            $bairro = $_POST['bairro'];
            $cidade = $_POST['cidade'];
            $estado = $_POST['estado'];
            $telefone = $_POST['telefone'];
            $email = $_POST['email'];
            $emailConfirma = $_POST['emailConfirma'];
            $sexo = $_POST['sexo'];
            $dia = $_POST['dia'];
            $mes = $_POST['mes'];
            $ano = $_POST['ano'];
            //SQL para inserir no Banco de Dados
            $sql = "INSERT INTO cadastro (nome, lagradouro, numero, bairro, cidade, estado, telefone, email, sexo, dia, mes, ano) VALUES ('$nome', '$lagradouro', '$numero', '$bairro', '$cidade', '$estado', '$telefone', '$email', '$sexo', '$dia', '$mes', '$ano')";

            $insert = mysqli_query($conexao, $sql);
            
                if(!$insert){
                    echo "<script>window.alert('Problema ao inserir no banco de dados.')</script>";
                }else{
                    $_SESSION['sucesso'] = "<div class='alert alert-success' role='alert'>Cadastrado com Sucesso!</div>";
                    echo "<script>window.location.href='cadastro.php'</script>";
                }
            }
        }else{ 
            $_SESSION['email_errado'] = "<div class='alert alert-danger alert-dismissible fade show' role='alert'>Email digitado não confere.</div>";
            echo "<script>window.location.href='cadastro.php'</script>";
        }
     }
 }
?>