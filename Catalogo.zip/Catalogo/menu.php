<div class="row">
            <div class="col-md-12">
                <center><h1 class="page-header">Catalogo Telefônico</h1></center>
                <ol class="breadcrumb">
                    <a style="margin: 5px;" class="btn btn-primary" href="index.php">Listar Catalogo Telefônico</a>
                    <a style="margin: 5px;" class="btn btn-primary" href="cadastro.php">Cadastrar</a>                
                </ol>
            </div>
    </div>