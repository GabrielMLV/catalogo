<!-- ALERTAS DE EXIBIÇÃO NA TELA INDEX -->

<?php
//cadastro alterado com sucesso
    if(!empty($_SESSION['alterado_sucesso'])){ //Se for diferente de vazio faça alguma coisa... $_SESSION variável global
       echo $_SESSION['alterado_sucesso']; //Imprimir a mensagem
       unset($_SESSION['alterado_sucesso']); // Destroi a variável global
    }
 ?>

<?php
//cadastro deletado com sucesso
    if(!empty($_SESSION['deletado'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
       echo $_SESSION['deletado']; // Imprimir a mensagem
       unset($_SESSION['deletado']); // Destroi a variável global
    }
?>

<?php
//alterar cadastro passando email de confirmação inválido
    if(!empty($_SESSION['alterar_email_invalido'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
       echo $_SESSION['alterar_email_invalido']; // Imprimir a mensagem
       unset($_SESSION['alterar_email_invalido']); // Destroi a variável global
    }
?>