<?php
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
include 'config.inc.php';
$id_cadastro = $_GET['id_cadastro']; //pegando ID passando no botão de alterar
$busca = "SELECT * FROM cadastro WHERE id_cadastro=$id_cadastro";
$sql = mysqli_query($conexao,$busca);
while($dados=mysqli_fetch_array($sql)){
?>

<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/estilo.css" rel="stylesheet">
<div class="container">
    <?php include 'menu.php'; ?>
        <div class="row">
            <form style="margin-top: 20px; background-color: #e9ecef;" class="form-control" action="alterarCadastroDB.php" method="post" enctype="multipart/form-data">
                <div class="text-center"><h3>Alterar</h3></div>
                <div class="form-group">
                    <!-- passando o ID -->
                <input type="hidden" name="id_cadastro" id="id_cadastro" value="<?=$dados['id_cadastro'];?>" />
                <div class="form-group">
                        <div class="form-row">
                            <div class="col-md-4">
                                <label>Nome:</label>
                                <input class="form-control" type="text" value="<?=$dados['nome'];?>" name="nome" required>
                            </div>
                            <div class="col-md-4">
                                <label>Endereço:</label>
                                <input class="form-control" type="text" value="<?=$dados['lagradouro'];?>" name="lagradouro" required>
                            </div>
                            <div class="col-md-4">
                                <label>Numero:</label>
                                <input class="form-control" type="text" pattern=".{2,5}" value="<?=$dados['numero'];?>" name="numero" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-3">
                                <label>Bairro:</label>
                                <input class="form-control" type="text" value="<?=$dados['bairro'];?>" name="bairro" required>
                            </div>
                            <div class="col-md-3">
                                <label>Cidade:</label>
                                <input class="form-control" type="text" value="<?=$dados['cidade'];?>" name="cidade" required>
                            </div>
                            <div class="col-md-3">
                                <label>Estado:</label>
                                <input class="form-control" type="text" value="<?=$dados['estado'];?>" name="estado" required>
                            </div>
                            <div class="col-md-3">
                                <label>Telefone:</label>
                                <input class="form-control" type="text" pattern=".{11,11}" value="<?=$dados['telefone'];?>" name="telefone" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-6">
                            <label>Email:</label>
                            <input class="form-control" type="email" value="<?=$dados['email'];?>" name="email" required>
                                <?php
                                    if(!empty($_SESSION['email_cadastrado'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                                        echo $_SESSION['email_cadastrado']; // Imprimir a mensagem
                                        unset($_SESSION['email_cadastrado']); // Destroi a variável global
                                    }
                                ?>
                            </div>
                            <div class="col-md-6">
                            <label>Confirmação de email:</label>
                            <input class="form-control" type="email" placeholder="Confirme o email digitado" name="emailConfirma" required>
                                <?php
                                    if(!empty($_SESSION['alterar_email_invalido'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                                        echo $_SESSION['alterar_email_invalido']; // Imprimir a mensagem
                                        unset($_SESSION['alterar_email_invalido']); // Destroi a variável global
                                    }
                                ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-2">
                                <label>Sexo:</label>
                                <label class="form-control" class="radio-inline">
                                <input type="radio" checked value="Masculino" name="sexo"> Masculino
                                </label>
                                <label class="form-control" class="radio-inline">
                                <input type="radio" value="Feminino" name="sexo"> Feminino
                                </label>
                            </div>
                       
                            <label>Data de Nascimento: </label>
                            <div class="col-md-1 text-center"> 
                                <label>Dia</label>
                                <input class="form-control" type="number" pattern=".{1,2}" value="<?=$dados['dia'];?>" name="dia">
                            </div>
                            <div class="col-md-1 text-center">
                                <label>Mês</label>
                                <input class="form-control" type="number" pattern=".{1,2}" value="<?=$dados['mes'];?>" name="mes">
                            </div>
                            <div class="col-md-1 text-center">
                                <label>Ano</label>
                                <input class="form-control" type="number" pattern=".{4,4}" value="<?=$dados['ano'];?>" name="ano">
                            </div>
                        </div>    
                        
                 </div> 
                <button class="btn btn-success" name="enviar">Alterar</button>
            </form>         
        </div>
    
</div>   
<?php
  }
?>