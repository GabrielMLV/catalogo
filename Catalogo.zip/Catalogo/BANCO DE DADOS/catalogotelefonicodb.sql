-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 16-Fev-2018 às 05:43
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `catalogotelefonicodb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `id_cadastro` int(4) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `lagradouro` varchar(255) NOT NULL,
  `numero` int(7) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sexo` varchar(30) NOT NULL,
  `dia` int(10) NOT NULL,
  `mes` int(10) NOT NULL,
  `ano` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cadastro`
--

INSERT INTO `cadastro` (`id_cadastro`, `nome`, `lagradouro`, `numero`, `bairro`, `cidade`, `estado`, `telefone`, `email`, `sexo`, `dia`, `mes`, `ano`) VALUES
(1, 'Matheus Pereira', 'Rua AntÃ´nio Correia ', 25, 'Mangabeira', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83911112222', 'matheus@gmail.com', 'Masculino', 11, 5, 1994),
(2, 'Maria da Silva', 'Rua Azevedo Fonseca', 35, 'Mangabeira', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83988888888', 'maria@gmail.com', 'Feminino', 8, 12, 1991),
(4, 'Rodrigo Dantas', 'Rua Correia de Vasconcelos', 564, 'BancÃ¡rios', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83977777777', 'rodrigo@gmail.com', 'Masculino', 16, 2, 1990),
(5, 'Ana Maria ', 'Rua Bandeirantes ', 279, 'Cidade Verde', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83922222222', 'ana@gmail.com', 'Feminino', 18, 4, 1988),
(6, 'Gabriela Maria', 'Rua Lima de Azevedo', 259, 'JosÃ© AmÃ©rico', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83955555555', 'gabriela@gmail.com', 'Feminino', 29, 8, 1989),
(7, 'Fernanda Monteiro', 'Rua Primavera Outono', 365, 'Torre', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83911111111', 'fernanda@gmail.com', 'Feminino', 11, 3, 1993),
(10, 'Jose da Silva', 'Rua Alfa', 155, 'BancÃ¡rios', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83988884444', 'jose@gmail.com', 'Masculino', 19, 6, 1989),
(11, 'JoÃ£o Pedro da Silva', 'Rua Beta ', 149, 'JosÃ© AmÃ©rico', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83944445555', 'joao@gmail.com', 'Masculino', 29, 7, 1996),
(12, 'Pedro Henrique', 'Rua Beta II', 320, 'BancÃ¡rios', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83999999999', 'pedro@gmail.com', 'Masculino', 28, 5, 1997),
(13, 'Igor Pereira de Souza', 'Rua Fonseca Junior', 137, 'Manaira', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83933333333', 'igor@gmail.com', 'Masculino', 27, 7, 1997),
(18, 'Gabriel Matheus ', 'Rua Vereador AntÃ´nio Correia de Vasconcelos', 236, 'Mangabeira', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83986466146', 'bielmatheus20@gmail.com', 'Masculino', 12, 7, 1996),
(20, 'Lucas Pinheiro', 'Rua da Tinta', 37, 'Cidade Verde', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83988883333', 'lucas@gmail.com', 'Masculino', 28, 10, 1987),
(21, 'Ana PatrÃ­cia ', 'Rua Alfredo', 119, 'Cristo', 'JoÃ£o Pessoa', 'ParaÃ­ba', '83912344321', 'anapatricia@gmail.com', 'Feminino', 31, 12, 1974);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`id_cadastro`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `id_cadastro` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
