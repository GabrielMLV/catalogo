<?php
session_start(); //Iniciando sessão para uso da variável super global $_SESSION para exibição de alertas
?>
<head>
    <title>Catalogo Telefônico</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet">
</head>
<div class="container">
    <?php include 'menu.php'; ?>
        <div class="card-body">
            <form style="margin-top: 20px; background-color: #e9ecef;" class="form-control" action="enviarCadastroDB.php" method="post" enctype="multipart/form-data"> <!-- Envio de dados para página EnviarCadastroDB  -->
                <div class="text-center"><h3>Cadastro</h3></div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col-md-4">
                                <label>Nome:</label>
                                <input class="form-control" type="text" placeholder="Informe seu nome" name="nome" required>
                            </div>
                            <div class="col-md-4">
                                <label>Endereço:</label>
                                <input class="form-control" type="text" placeholder="Lagradouro" name="lagradouro" required>
                            </div>
                            <div class="col-md-4">
                                <label>Numero:</label>
                                <input class="form-control" type="number" pattern=".{1,5}" placeholder="Número" name="numero" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-3">
                                <label>Bairro:</label>
                                <input class="form-control" type="text" placeholder="Bairro" name="bairro" required>
                            </div>
                            <div class="col-md-3">
                                <label>Cidade:</label>
                                <input class="form-control" type="text" placeholder="Cidade" name="cidade" required>
                            </div>
                            <div class="col-md-3">
                                <label>Estado:</label>
                                <input class="form-control" type="text" placeholder="Estado" name="estado" required>
                            </div>
                            <div class="col-md-3">
                                <label>Telefone:</label>
                                <input class="form-control" type="text" pattern=".{11,11}" placeholder="Telefone ex: 83988887777" name="telefone" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-6">
                            <label>Email:</label>
                            <input class="form-control" type="email" placeholder="Email" name="email" required>
                                <?php
                                    if(!empty($_SESSION['email_cadastrado'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                                        echo $_SESSION['email_cadastrado']; // Imprimir a mensagem
                                        unset($_SESSION['email_cadastrado']); // Destroi a variável global
                                    }
                                ?>
                            </div>
                            <div class="col-md-6">
                            <label>Confirmação de email:</label>
                            <input class="form-control" type="email" placeholder="Confirme o email digitado" name="emailConfirma" required>
                                <?php
                                    if(!empty($_SESSION['email_errado'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                                        echo $_SESSION['email_errado']; // Imprimir a mensagem
                                        unset($_SESSION['email_errado']); // Destroi a variável global
                                    }
                                ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-2">
                                <label>Sexo:</label>
                                <label class="form-control" class="radio-inline">
                                <input type="radio" value="Masculino" name="sexo" required> Masculino
                                </label>
                                <label class="form-control" class="radio-inline">
                                <input type="radio" value="Feminino" name="sexo" required> Feminino
                                </label>
                            </div>
                       
                            <label>Data de Nascimento: </label>
                            <div class="col-md-1 text-center"> 
                                <label>Dia</label>
                                <input class="form-control" type="number" pattern=".{1,2}" placeholder="DD" name="dia" required>
                            </div>
                            <div class="col-md-1 text-center">
                                <label>Mês</label>
                                <input class="form-control" type="number" pattern=".{1,2}" placeholder="MM" name="mes" required>
                            </div>
                            <div class="col-md-1 text-center">
                                <label>Ano</label>
                                <input class="form-control" type="number" pattern=".{4,4}" placeholder="AAAA" name="ano" required>
                            </div>
                            <?php
                                if(!empty($_SESSION['data_errada'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                                    echo $_SESSION['data_errada']; // Imprimir a mensagem
                                    unset($_SESSION['data_errada']); // Destroi a variável global
                                }
                            ?>
                        </div>    
                        
                 </div>       
                <button class="btn btn-success" name="enviar">Enviar</button>
                <?php
                    if(!empty($_SESSION['sucesso'])){ // Se for diferente de vazio faça alguma coisa... $_SESSION variável global
                        echo $_SESSION['sucesso']; // Imprimir a mensagem
                        unset($_SESSION['sucesso']); // Destroi a variável global
                    }
                ?>
            </form>           
        </div>   
</div>   